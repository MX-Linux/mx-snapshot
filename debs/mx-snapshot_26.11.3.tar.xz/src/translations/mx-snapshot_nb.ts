<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nb">
<context>
    <name>Batchprocessing</name>
    <message>
        <location filename="../src/batchprocessing.cpp" line="92"/>
        <source>Use --allow-omitted-mounts to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="105"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="106"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Den gjeldende kjernen støtter ikke valgt komprimeringsalgoritme. Rediger oppsettsfila og velg en annen algoritme.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="126"/>
        <source>Warning: these services in /etc/systemd/system contain what look like passwords, tokens or keys, and will be included in the snapshot as they are:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="131"/>
        <source>Warning: these service files or folders could not be checked for passwords, tokens or keys, and will be included in the snapshot as they are:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="178"/>
        <source>The program will pause the build and open the boot menu in your text editor.</source>
        <translation>Programmet vil pause generering og åpne oppstartsmenyen i et tekstprogram.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="194"/>
        <source>The boot-menu editor failed; the snapshot cannot continue with potentially unedited files.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="223"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="350"/>
        <source>Detected newer exclusion file at %1 compared to %2. Prompting for action.</source>
        <translation>Nyere ekskluderingsfil oppdaget på %1 sammenliknet med %2. Handling kreves.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="357"/>
        <source>s</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'show diff'</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="358"/>
        <source>u</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'use updated default'</comment>
        <translation>u</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="359"/>
        <source>k</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'keep custom (update timestamp)'</comment>
        <translation>k</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="360"/>
        <source>q</source>
        <comment>CLI excludes prompt: single-letter shortcut for 'quit'</comment>
        <translation>q</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="362"/>
        <source>show diff</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>vis forskjell</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="363"/>
        <source>use updated default</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>bruk oppdatert standard</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="364"/>
        <source>keep custom (update timestamp)</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>behold tilpasset (oppdater tidsstempel)</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="365"/>
        <source>quit</source>
        <comment>CLI excludes prompt option label</comment>
        <translation>avslutt</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="368"/>
        <source>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </source>
        <translation>[%1]%2  [%3]%4  [%5]%6  [%7]%8: </translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="373"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Ekskluderingsfilen på %1 er nyere enn din konfigurerte fil på %2.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="389"/>
        <source>Reverted to updated default exclusion file.</source>
        <translation>Tilbakestilt til oppdatert standard ekskluderingsfil.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="392"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="408"/>
        <source>No input available to answer the exclusion file prompt; aborting without creating a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="411"/>
        <source>Leaving custom exclusion file unchanged.</source>
        <translation>Tilpasset ekskluderingsfil beholdes uendret.</translation>
    </message>
    <message>
        <location filename="../src/batchprocessing.cpp" line="422"/>
        <source>Invalid choice. Please select again.</source>
        <translation>Ugyldig valg. Velg på nytt.</translation>
    </message>
</context>
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="121"/>
        <source>No elevation tool found (pkexec/gksu/sudo).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="217"/>
        <source>Failed to start command: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="288"/>
        <source>Administrator access was not granted (authentication cancelled or denied).</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <location filename="../src/mainwindow.cpp" line="403"/>
        <location filename="../src/mainwindow.cpp" line="1041"/>
        <source>MX Snapshot</source>
        <translation>MX ISO-bilde</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Optional customization</source>
        <translation>Valgfri tilpasning</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="65"/>
        <source>Release version:</source>
        <translation>Utgitt versjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="79"/>
        <source>Boot options:</source>
        <translation>Oppstartsalternativer:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="86"/>
        <source>Live kernel:</source>
        <translation>Live-kjerne:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Project name:</source>
        <translation>Prosjektnavn:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="100"/>
        <source>Release date:</source>
        <translation>Utgivelsesdato:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Release codename:</source>
        <translation>Utgivelsens kodenavn:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Current date</source>
        <translation>Gjeldende dato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Snapshot is a utility that creates a bootable image (ISO) of your working system that you can use for storage or distribution. You can continue working with undemanding applications while it is running.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ISO-bilde er et verktøy som kan lage en oppstartbar avbildning (ISO) av systemet, som kan brukes som reservekopi eller til videreformidling. Programmer som bruker små systemressurser kan fortsette å kjøre mens dette verktøyet arbeider.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Used space on / (root) and /home partitions:</source>
        <translation>Brukt plass på / (rot-) og /home-partisjoner:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="192"/>
        <source>Location and ISO name</source>
        <translation>Plassering og ISO-navn</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="219"/>
        <source>Snapshot location:</source>
        <translation>Bildets plassering:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="226"/>
        <source>Select a different snapshot directory</source>
        <translation>Velg en annen mappe for bildet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="236"/>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>Snapshot name:</source>
        <translation>Bildets navn:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="360"/>
        <source>Type of snapshot:</source>
        <translation>Type ISO-bilde:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="367"/>
        <source>Preserving accounts (for personal backup)</source>
        <translation>Bevarer kontoer (for personlig sikkerhetskopi)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This option will reset &amp;quot;demo&amp;quot; and &amp;quot;root&amp;quot; passwords to the MX Linux defaults and will not copy any personal accounts created.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dette alternativet vil tilbakestille passordene til &amp;quot;demo&amp;quot; og &amp;quot;root&amp;quot; til sine MX Linux-forvalg, og vil ikke kopiere noen personlige kontoer som er opprettet.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="380"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Tilbakestiller kontoer (for videreformidling til andre)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="451"/>
        <source>You can also exclude certain directories by ticking the common choices below, or by clicking on the button to directly edit /etc/mx-snapshot-exclude.list.</source>
        <translation>Mapper kan ekskluderes ved å velge dem nedenfor, eller ved å velge knappen for å selv redigere /etc/snapshot-exclude.list.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Throttle the I/O input rate by the given percentage.</source>
        <translation>Strup I/U-forholdet med en gitt prosent.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="525"/>
        <source>I/O throttle:</source>
        <translation>I/U-struping:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="532"/>
        <source>Calculate checksums:</source>
        <translation>Beregn sjekksummer:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="539"/>
        <source>ISO compression scheme:</source>
        <translation>Komprimeringstype for ISO:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Number of CPU cores to use:</source>
        <translation>Antall CPU-kjerner å bruke:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="553"/>
        <source>md5</source>
        <translation>md5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="563"/>
        <source>Options:</source>
        <translation>Valg:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="610"/>
        <source>Edit Exclusion File</source>
        <translation>Rediger ekskluderingsfil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="626"/>
        <location filename="../src/mainwindow.cpp" line="1066"/>
        <source>Remove Custom Exclusion File</source>
        <translation>Fjern tilpasset ekskluderingsfil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="679"/>
        <source>Pictures</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <source>Videos</source>
        <translation>Videoer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="693"/>
        <source>All of the above</source>
        <translation>Alle over</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>exclude network configurations</source>
        <translation>ekskluder nettverksoppsett</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="703"/>
        <source>Networks</source>
        <translation>Nettverk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="710"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="717"/>
        <source>Desktop</source>
        <translation>Skrivebord</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="724"/>
        <source>Documents</source>
        <translation>Dokumenter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="731"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="738"/>
        <source>Music</source>
        <translation>Musikk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="881"/>
        <source>About this application</source>
        <translation>Om programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="884"/>
        <source>About...</source>
        <translation>Om …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="890"/>
        <source>Alt+B</source>
        <translation>Alt + B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1005"/>
        <source>Next</source>
        <translation>Neste</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="906"/>
        <source>Display help </source>
        <translation>Vis hjelp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="909"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <source>Alt+H</source>
        <translation>Alt + H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <source>Quit application</source>
        <translation>Avslutt programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1039"/>
        <source>Alt+N</source>
        <translation>Alt + N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="989"/>
        <source>Back</source>
        <translation>Tilbake</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="365"/>
        <source>Select Release Date</source>
        <translation>Velg utgivelsesdato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="409"/>
        <source>fastest, worst compression</source>
        <translation>raskest, dårligst komprimering</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="409"/>
        <source>fast, worse compression</source>
        <translation>rask, dårlig komprimering</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <source>slow, better compression</source>
        <translation>treig, bedre komprimering</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="410"/>
        <source>best compromise</source>
        <translation>beste kompromiss</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="411"/>
        <source>slowest, best compression</source>
        <translation>treigeste, beste komprimering</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="439"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Ledig plass på %1, der mappa til ISO-bildet legges:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="442"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space by removing previous snapshots and saved copies: %1 snapshots are taking up %2 of disk space.</source>
        <translation>Det bør være nok ledig plass til de komprimerte dataene fra / og /home

    Hvis nødvendig så kan du frigjøre plass ved å
    fjerne gamle ISO-bilder og lagrede kopier:
    %1 ISO-bilder bruker %2 diskplass.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="454"/>
        <location filename="../src/mainwindow.cpp" line="455"/>
        <source>Installing </source>
        <translation>Installerer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="602"/>
        <source>Please wait.</source>
        <translation>Vennligst vent.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="604"/>
        <source>Please wait. Calculating used disk space...</source>
        <translation>Vennligst vent. Beregner brukt diskplass …</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="282"/>
        <location filename="../src/mainwindow.cpp" line="504"/>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <location filename="../src/mainwindow.cpp" line="649"/>
        <location filename="../src/mainwindow.cpp" line="656"/>
        <location filename="../src/mainwindow.cpp" line="739"/>
        <location filename="../src/mainwindow.cpp" line="750"/>
        <location filename="../src/mainwindow.cpp" line="790"/>
        <location filename="../src/mainwindow.cpp" line="1131"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="182"/>
        <location filename="../src/mainwindow.cpp" line="218"/>
        <source>Updated Exclusion List</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>The exclusion file at %1 is newer than your configured file at %2.</source>
        <translation>Ekskluderingsfilen på %1 er nyere enn din konfigurerte fil på %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="187"/>
        <source>Review the changes below. Keep your custom file or replace it with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Show Differences</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="199"/>
        <source>Keep Custom</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="205"/>
        <source>Use Updated Default</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="505"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="537"/>
        <source>Done</source>
        <translation>Ferdig</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Utfila %1 finnes allerede. Velg et annet filnavn eller slett eksisterende fil.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="657"/>
        <source>Insufficient free space. Please select a different snapshot directory or free up space.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="661"/>
        <source>Settings</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="667"/>
        <source>Snapshot will use the following settings:</source>
        <translation>ISO-bilde vil bruke de følgende innstillingene:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="669"/>
        <source>- Snapshot directory:</source>
        <translation>– ISO-bildets mappe:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="670"/>
        <source>- Kernel to be used:</source>
        <translation>– Kjerne som skal brukes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="695"/>
        <location filename="../src/mainwindow.cpp" line="704"/>
        <source>NVIDIA Detected</source>
        <translation>Oppdaget NVIDIA</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="696"/>
        <source>This computer uses an NVIDIA graphics card. Are you planning to use the resulting ISO on the same computer or another computer with an NVIDIA card?</source>
        <translation>Denne datamaskinen bruker et grafikkort fra NVIDIA. Skal ISO-bildet brukes på denne maskinen, eller en annen maskin med NVIDIA-kort?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="700"/>
        <source>NVIDIA Selected</source>
        <translation>NVIDIA er valgt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Note: If you use the resulting ISO on a computer without an NVIDIA card, you will likely need to remove &apos;xorg=nvidia&apos; from the boot options.</source>
        <translation>Merknad: Oppstartsalternativet &apos;xorg=nvidia&apos; må sannsynligvis fjernes hvis ISO-bildet skal brukes på en datamaskin uten NVIDIA-kort.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="705"/>
        <source>Note: If you use the resulting ISO on a computer with an NVIDIA card, you may need to add &apos;xorg=nvidia&apos; to the boot options.</source>
        <translation>Merknad: Oppstartsalternativet &apos;xorg=nvidia&apos; må sannsynligvis legges til hvis ISO-bilde skal brukes på en datamaskin med NVIDIA-kort.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="283"/>
        <location filename="../src/mainwindow.cpp" line="740"/>
        <source>Could not replace the exclusion file with the updated default.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="751"/>
        <source>Current kernel doesn&apos;t support selected compression algorithm, please edit the configuration file and select a different algorithm.</source>
        <translation>Den gjeldende kjernen støtter ikke valgt komprimeringsalgoritme. Rediger oppsettsfila og velg en annen algoritme.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="786"/>
        <source>Cancelled</source>
        <translation>Kansellert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <source>Administrator access is required to create a snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <source>The operation was cancelled. Select Next when you are ready to try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="791"/>
        <source>Could not create the snapshot or work directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="817"/>
        <source>These services in /etc/systemd/system contain what look like passwords, tokens or keys, and will be included in the snapshot as they are:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="823"/>
        <source>These service files or folders could not be checked for passwords, tokens or keys, and will be included in the snapshot as they are:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>Every system started or installed from this ISO will have them. If the ISO will be shared, remove the credentials from these files or add the files to the exclusion list. Disabling a service is not enough: its files are still copied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="830"/>
        <source>Continue anyway?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="832"/>
        <source>Credentials in services</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="840"/>
        <source>Final chance</source>
        <translation>Siste sjanse</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="842"/>
        <source>Snapshot now has all the information it needs to create an ISO from your running system.</source>
        <translation>Programmet har nå all nødvendig informasjon for å kunne opprette et ISO-bilde av det kjørende systemet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>It will take some time to finish, depending on the size of the installed system and the capacity of your computer.</source>
        <translation>Dette vil ta noe tid, avhengig av størrelsen til det installerte systemet og hvor kraftig datamaskinen er.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>OK to start?</source>
        <translation>Klar til start?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="824"/>
        <location filename="../src/mainwindow.cpp" line="855"/>
        <source>Shutdown computer when done.</source>
        <translation>Slå av datamaskinen ved fullføring.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="901"/>
        <source>Output</source>
        <translation>Utdata</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="946"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1021"/>
        <source>Edit Boot Menu</source>
        <translation>Rediger oppstartsmeny</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1022"/>
        <source>The program will now pause to allow you to edit any files in the work directory. Select Yes to edit the boot menu or select No to bypass this step and continue creating the snapshot.</source>
        <translation>Programmet vil nå pause slik at du kan redigere filer i arbeidsmappa. Velg «Ja» for å redigere oppstartsmenyen eller «Nei» for å hoppe over dette trinnet og fortsette med opprettelsen av ISO-bildet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1067"/>
        <source>Revert the exclusion list to the default file? This will overwrite your current exclusions.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1099"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1101"/>
        <source>Version: </source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1102"/>
        <source>Program for creating a live-CD from the running system for MX Linux</source>
        <translation>Program for å opprette en live-CD for det kjørende systemet, for MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1104"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Opphavsrett (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1106"/>
        <source>%1 License</source>
        <translation>Lisens for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1119"/>
        <source>%1 Help</source>
        <translation>Hjelpetekst for %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1124"/>
        <source>Select Snapshot Directory</source>
        <translation>Velg mappe for ISO-bilde</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1132"/>
        <source>Insufficient free space in the selected directory. Please choose a different location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <source>Confirmation</source>
        <translation>Bekreft</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <source>Are you sure you want to quit the application?</source>
        <translation>Vil du virkelig avslutte dette programmet?</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/main.cpp" line="119"/>
        <source>Tool used for creating a live-CD from the running system</source>
        <translation>Program for å opprette en live-CD for det kjørende systemet</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="123"/>
        <source>Use CLI only</source>
        <translation>Kun kommandolinje</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="127"/>
        <source>Number of CPU cores to be used.</source>
        <translation>Antall CPU-kjerner som skal brukes.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="128"/>
        <source>Output directory</source>
        <translation>Mappe med utdata</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="129"/>
        <source>Output filename</source>
        <translation>Utdatas filnavn</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="131"/>
        <source>Name a different kernel to use other than the default running kernel, use format returned by &apos;uname -r&apos;</source>
        <translation>Angi en annen kjerne enn den kjørende; bruk formatet gitt av &apos;uname -r&apos;</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="133"/>
        <source>Or the full path: %1</source>
        <translation>Eller full sti: %1</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Compression level options.</source>
        <translation>Velg komprimeringsnivå.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="137"/>
        <source>Use quotes: &quot;-Xcompression-level &lt;level&gt;&quot;, or &quot;-Xalgorithm &lt;algorithm&gt;&quot;, or &quot;-Xhc&quot;, see mksquashfs man page</source>
        <translation>Bruk sitattegn: &quot;-Xcompression-level &lt;level&gt;&quot; eller &quot;-Xalgoritm &lt;algorithm&gt;&quot; eller &quot;-Xhc&quot;, se man-siden til mksquashfs</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="141"/>
        <source>Create a monthly snapshot, add &apos;Month&apos; name in the ISO name, skip used space calculation</source>
        <translation>Lag et månedlig ISO-bilde. Legg til måneden i ISO-navnet og hopp over beregning av brukt plass.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="142"/>
        <source>This option sets reset-accounts and compression to defaults, arguments changing those items will be ignored</source>
        <translation>Dette alternativet tilbakestiller «reset-accounts» og «compression» til forvalgte verdier, og argumenter som endrer disse to vil bli ignorert</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <source>Optionally specify a suffix to add to the month name (e.g., &apos;1&apos; for &apos;July.1&apos;)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="145"/>
        <source>Don&apos;t calculate checksums for resulting ISO file</source>
        <translation>Ikke beregn sjekksummer for resulterende ISO-fil</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="146"/>
        <source>Skip calculating free space to see if the resulting ISO will fit</source>
        <translation>Hopp over beregning av ledig diskplass for å sjekke om resulterende ISO vil passe</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="147"/>
        <source>Allow CLI snapshots that omit separately mounted /usr or /var</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="148"/>
        <source>Option to fix issue with calculating checksums on preempt_rt kernels</source>
        <translation>Alternativ som løser et problem med beregning av sjekksummer på preempt_rt-kjerner</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="149"/>
        <source>Resetting accounts (for distribution to others)</source>
        <translation>Tilbakestiller kontoer (for videreformidling til andre)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="150"/>
        <source>Calculate checksums for resulting ISO file</source>
        <translation>Beregn sjekksummer for resulterende ISO-fil</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="152"/>
        <source>Throttle the I/O input rate by the given percentage. This can be used to reduce the I/O and CPU consumption of Mksquashfs.</source>
        <translation>Strup I/U-forholdet med den gitte prosenten. Dette reduserer I/U- og CPU-forbruket til Mksquashfs.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="155"/>
        <source>Work directory</source>
        <translation>Arbeidsmappe</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="157"/>
        <source>Exclude main folders, valid choices: </source>
        <translation>Utelat hovedmapper; gyldige alternativer:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="159"/>
        <source>Use the option one time for each item you want to exclude</source>
        <translation>Bruk alternativet én gang for hvert element som skal utelates</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="162"/>
        <source>Compression format, valid choices: </source>
        <translation>Komprimeringsformat; gyldige alternativer:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="164"/>
        <source>Shutdown computer when done.</source>
        <translation>Slå av datamaskinen ved fullføring.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="165"/>
        <source>Use grub for legacy mbr iso boot instead of isolinux/syslinux.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="166"/>
        <source>Add the &apos;xorg=nvidia&apos; boot option to the ISO (for booting on a system with an NVIDIA card).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="174"/>
        <source>Optional suffix for a monthly snapshot; only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="197"/>
        <source>A single suffix positional argument is only valid together with --month.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="261"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du er innlogget som root. Vennligst logg ut, og logg inn igjen som en vanlig bruker for å bruke dette programmet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="278"/>
        <source>version:</source>
        <translation>versjon:</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="272"/>
        <source>You must run this program with sudo or pkexec.</source>
        <translation>Dette programmet må kjøres med sudo eller pkexec.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="236"/>
        <source>MX Snapshot</source>
        <translation>MX ISO-bilde</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="263"/>
        <location filename="../src/main.cpp" line="342"/>
        <location filename="../src/main.cpp" line="348"/>
        <location filename="../src/main.cpp" line="388"/>
        <location filename="../src/settings.cpp" line="785"/>
        <location filename="../src/settings.cpp" line="794"/>
        <location filename="../src/settings.cpp" line="1464"/>
        <location filename="../src/settings.cpp" line="1571"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="287"/>
        <source>Cancelled before the snapshot started.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="316"/>
        <source>Fatal error:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="318"/>
        <source>Fatal error: unknown exception</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="343"/>
        <source>Another snapshot is already running (MX Snapshot or iso-snapshot-cli). Wait for it to finish, then try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="349"/>
        <source>Cannot use the lock file %1 (%2). It keeps two snapshots from running at once. Restarting the computer clears it, or an administrator can delete the file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="387"/>
        <location filename="../src/settings.cpp" line="793"/>
        <source>Current kernel doesn&apos;t support Squashfs, cannot continue.</source>
        <translation>Gjeldende kjerne støtter ikke Squashfs. Kan ikke fortsette.</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="279"/>
        <source>Exception during initialization: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="234"/>
        <source>Pending Arch bind-root cleanup state but installed-to-live-arch is missing: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="282"/>
        <source>Unknown exception during initialization</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="319"/>
        <source>Could not create work directory. </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="402"/>
        <source>No suitable filesystem found for the temp directory. Tried /tmp, /home, and the snapshot directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="413"/>
        <source>Could not create temp directory:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="414"/>
        <source>Please check that the parent directory exists and is writable:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="432"/>
        <source>Compression format &apos;%1&apos; is not supported by the current kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="438"/>
        <source>Invalid cores setting: %1. Must be between 1 and %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="447"/>
        <source>Invalid throttle setting: %1. Must be between 0 and 99</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="453"/>
        <source>Snapshot directory cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="510"/>
        <source>Snapshot name cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="514"/>
        <source>Snapshot name contains invalid characters: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="466"/>
        <source>Kernel version cannot be empty</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="471"/>
        <source>Kernel file not found: /boot/vmlinuz-%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="478"/>
        <source>Kernel %1 doesn&apos;t support Squashfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="525"/>
        <source>Exclusion file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="545"/>
        <source>Insufficient free space: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="552"/>
        <source>Insufficient free space in work directory: %1 KiB available, minimum %2 KiB required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="567"/>
        <source>Failed to determine number of CPU cores</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="573"/>
        <source>Configuration file does not exist: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="574"/>
        <source>Using default settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="576"/>
        <source>Cannot read configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="577"/>
        <source>Error: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="587"/>
        <source>Required tool not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="596"/>
        <source>Required directory not found: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="615"/>
        <source>Initialization Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="616"/>
        <source>Failed to initialize application settings:

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="783"/>
        <source>Could not find a usable kernel</source>
        <translation>Fant ingen brukbar kjerne</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="784"/>
        <source>Searched for kernel files in /boot/ but none were found or accessible.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="805"/>
        <source>No users found in the system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="808"/>
        <source>Failed to determine system information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="968"/>
        <source>Used space on / (root): </source>
        <translation>Brukt plass på / (rot):</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="984"/>
        <source>estimated</source>
        <translation>estimert</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="991"/>
        <source>Used space on /home: </source>
        <translation>Brukt plass på /home:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1052"/>
        <source>Free space on %1, where snapshot folder is placed: </source>
        <translation>Ledig plass på %1, der mappa til ISO-bildet legges:</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1056"/>
        <source>The free space should be sufficient to hold the compressed data from / and /home

      If necessary, you can create more available space
      by removing previous snapshots and saved copies:
      %1 snapshots are taking up %2 of disk space.
</source>
        <translation>Det bør være nok ledig plass til de komprimerte dataene fra / og /home

    Hvis nødvendig så kan du frigjøre plass ved å
    fjerne gamle ISO-bilder og lagrede kopier:
    %1 ISO-bilder bruker %2 diskplass.
</translation>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1209"/>
        <source>Error reading system configuration file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1218"/>
        <source>Error accessing user configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1250"/>
        <source>Could not create user configuration directory: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1271"/>
        <source>Could not copy exclusion file from %1 to %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1294"/>
        <source>Unsupported compression &apos;%1&apos; in configuration, using zstd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1309"/>
        <source>Unsupported --compression-level value: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1312"/>
        <source>Ignoring unsupported mksq_opt in %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1324"/>
        <source>Invalid stored cores setting (%1). Using detected CPU count: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1334"/>
        <source>Invalid stored throttle setting (%1). Using 0.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/settings.cpp" line="1462"/>
        <location filename="../src/settings.cpp" line="1569"/>
        <source>Output file %1 already exists. Please use another file name, or delete the existent file.</source>
        <translation>Utfila %1 finnes allerede. Velg et annet filnavn eller slett eksisterende fil.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>License</source>
        <translation>Lisens</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <location filename="../src/about.cpp" line="107"/>
        <source>Changelog</source>
        <translation>Endringslogg</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="98"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="119"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="53"/>
        <location filename="../src/about.cpp" line="122"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="78"/>
        <source>No diff output available.</source>
        <translation>Ingen diff-resultat tilgjengelig.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="91"/>
        <source>Could not open default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="97"/>
        <source>Could not create exclusion file directory at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="106"/>
        <source>Could not prepare exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="123"/>
        <source>Could not read default exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="131"/>
        <source>Could not write exclusion file at %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="113"/>
        <source>Could not backup existing exclusion file to %1.</source>
        <translation>Kunne ikke ta sikkerhetskopi av eksisterende ekskluderingsfil til %1.</translation>
    </message>
    <message>
        <location filename="../src/excludesutils.cpp" line="139"/>
        <source>Could not copy default exclusion file from %1 to %2.</source>
        <translation>Kunne ikke kopiere standard ekskluderingsfil fra %1 til %2.</translation>
    </message>
    <message>
        <location filename="../src/systeminfo.cpp" line="28"/>
        <location filename="../src/systeminfo.cpp" line="34"/>
        <source>Could not determine whether /usr and /var are separate mounts.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/systeminfo.cpp" line="44"/>
        <source>The snapshot will omit the mounted contents of %1. The resulting ISO may be unusable.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Work</name>
    <message>
        <location filename="../src/work.cpp" line="339"/>
        <source>Cleaning...</source>
        <translation>Rengjøring …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="366"/>
        <location filename="../src/work.cpp" line="1353"/>
        <source>Done</source>
        <translation>Ferdig</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="381"/>
        <source>Interrupted or failed to complete</source>
        <translation>Avbrutt, eller klarte ikke fullføre</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="393"/>
        <location filename="../src/work.cpp" line="449"/>
        <location filename="../src/work.cpp" line="696"/>
        <location filename="../src/work.cpp" line="704"/>
        <location filename="../src/work.cpp" line="739"/>
        <location filename="../src/work.cpp" line="754"/>
        <location filename="../src/work.cpp" line="799"/>
        <location filename="../src/work.cpp" line="824"/>
        <location filename="../src/work.cpp" line="840"/>
        <location filename="../src/work.cpp" line="852"/>
        <location filename="../src/work.cpp" line="862"/>
        <location filename="../src/work.cpp" line="876"/>
        <location filename="../src/work.cpp" line="884"/>
        <location filename="../src/work.cpp" line="890"/>
        <location filename="../src/work.cpp" line="898"/>
        <location filename="../src/work.cpp" line="914"/>
        <location filename="../src/work.cpp" line="953"/>
        <location filename="../src/work.cpp" line="962"/>
        <location filename="../src/work.cpp" line="977"/>
        <location filename="../src/work.cpp" line="1038"/>
        <location filename="../src/work.cpp" line="1053"/>
        <location filename="../src/work.cpp" line="1061"/>
        <location filename="../src/work.cpp" line="1072"/>
        <location filename="../src/work.cpp" line="1080"/>
        <location filename="../src/work.cpp" line="1286"/>
        <location filename="../src/work.cpp" line="1306"/>
        <location filename="../src/work.cpp" line="1323"/>
        <location filename="../src/work.cpp" line="1336"/>
        <location filename="../src/work.cpp" line="1344"/>
        <location filename="../src/work.cpp" line="1405"/>
        <location filename="../src/work.cpp" line="1729"/>
        <location filename="../src/work.cpp" line="1737"/>
        <location filename="../src/work.cpp" line="1751"/>
        <location filename="../src/work.cpp" line="1790"/>
        <location filename="../src/work.cpp" line="1833"/>
        <location filename="../src/work.cpp" line="1848"/>
        <location filename="../src/work.cpp" line="1863"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="394"/>
        <source>Administrator access was not granted; the snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="450"/>
        <source>There&apos;s not enough free space on your target disk, you need at least %1</source>
        <translation>Det er ikke nok ledig plass på måldisken. Det trengs minst %1</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="453"/>
        <source>You have %1 free space on %2</source>
        <translation>Det er %1 ledig plass på %2</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="456"/>
        <source>If you are sure you have enough free space rerun the program with -o/--override-size option</source>
        <translation>Kjør programmet på nytt med valget -o/--override-size hvis det er nok ledig diskplass</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="677"/>
        <source>Copying the new-iso filesystem...</source>
        <translation>Kopierer det nye ISO-filsystemet …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="696"/>
        <source>ISO template not found: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="704"/>
        <location filename="../src/work.cpp" line="862"/>
        <source>Could not extract the ISO template: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="732"/>
        <source>Arch ISO template is missing boot/ or efi/ directories.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="735"/>
        <source>Detected boot/ or efi/ under the work directory root; the template may have been extracted to the wrong location.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="738"/>
        <source>Template: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="754"/>
        <source>Could not copy %1 to %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="785"/>
        <source>Stale archiso initramfs detected, rebuilding...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="789"/>
        <source>Could not determine the kernel version of /boot/archiso.img (selected kernel is %1).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="792"/>
        <source>Found /boot/archiso.img built for kernel %1, but the selected kernel is %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="796"/>
        <source>Rebuilding /boot/archiso.img failed; check the mkinitcpio output in the log for errors (e.g. a missing hook). Please fix them and rebuild it manually, or remove the stale file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="808"/>
        <source>No /boot/archiso.img found, attempting to create one...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="825"/>
        <source>Could not verify that %1 matches the selected kernel %2. Rebuild the archiso initramfs for this kernel.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="841"/>
        <source>Could not verify the archiso live boot hook in %1. Rebuild the initramfs with the archiso hook.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="846"/>
        <source>Using %1 with the archiso live boot hook.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1395"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="852"/>
        <source>Could not find an initramfs image to use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="877"/>
        <source>--grub-mbr option specified but boot/grub/i386-pc/eltorito.img is missing from iso-template</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="885"/>
        <source>Could not copy the template initrd: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="891"/>
        <source>Could not copy the kernel: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="899"/>
        <location filename="../src/work.cpp" line="978"/>
        <location filename="../src/work.cpp" line="1062"/>
        <location filename="../src/work.cpp" line="1081"/>
        <source>Could not create the checksum for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="907"/>
        <source>Could not create temp directory. </source>
        <translation>Klarte ikke å opprette midlertidig mappe.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="914"/>
        <source>Could not extract the template initrd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="954"/>
        <source>Could not copy the kernel modules or programs into the initrd.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="963"/>
        <source>Could not create the new initrd: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1028"/>
        <source>Squashing filesystem...</source>
        <translation>Pakker filsystemet …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1039"/>
        <source>Could not create linuxfs file, please check /var/log/%1.log</source>
        <translation>Klarte ikke opprette linuxfs-fil. Undersøk /var/log/%1.log</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1054"/>
        <location filename="../src/work.cpp" line="1073"/>
        <source>Could not move %1 to the ISO directory.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1277"/>
        <source>Creating CD/DVD image file...</source>
        <translation>Oppretter CD-/DVD-bildefil …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1286"/>
        <source>Could not create %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1307"/>
        <source>Could not create ISO file, please check whether you have enough space on the destination partition.</source>
        <translation>Klarte ikke å opprette ISO-fil. Se etter om det er nok ledig plass på målpartisjonen.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1317"/>
        <source>Making hybrid iso</source>
        <translation>Lager hybrid-ISO</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1324"/>
        <source>Could not make the ISO hybrid; it would not boot correctly from USB.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1337"/>
        <location filename="../src/work.cpp" line="1345"/>
        <source>Could not create the %1 checksum for the ISO.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1358"/>
        <source>Success</source>
        <translation>Vellykket</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1359"/>
        <source>MX Snapshot completed successfully!</source>
        <translation>Opprettet ISO-bilde</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1360"/>
        <source>Snapshot took %1 to finish.</source>
        <translation>Tidsbruk %1.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1361"/>
        <source>Thanks for using MX Snapshot, run MX Live USB Maker next!</source>
        <translation>Takk for at du brukte MX ISO-bilde – nå kan du kjøre MX Live-USB.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1376"/>
        <location filename="../src/work.cpp" line="1402"/>
        <source>Installing </source>
        <translation>Installerer</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1391"/>
        <source>paru not found; cannot install %1 from the AUR.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1396"/>
        <source>Could not install %1; continuing without the installer.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1405"/>
        <source>Could not install </source>
        <translation>Klarte ikke å installere</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1415"/>
        <source>Calculating checksum...</source>
        <translation>Beregner sjekksum …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1468"/>
        <source>Building new initrd...</source>
        <translation>Bygger ny initrd …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1540"/>
        <source>Rebuilding initramfs with: mkinitcpio %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1729"/>
        <location filename="../src/work.cpp" line="1751"/>
        <source>Could not create the package list: </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1738"/>
        <source>Could not create working directory. </source>
        <translation>Klarte ikke å opprette arbeidsmappe.</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1791"/>
        <source>Could not prepare a safe bind-root overlay. Snapshot cannot continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1834"/>
        <location filename="../src/work.cpp" line="1864"/>
        <source>Could not prepare the snapshot bind-root environment.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="1849"/>
        <source>Could not remove this computer&apos;s snap store registration from the snapshot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/work.cpp" line="2199"/>
        <source>Calculating total size of excluded files...</source>
        <translation>Beregner den totale størrelsen til utelukkede filer …</translation>
    </message>
    <message>
        <location filename="../src/work.cpp" line="2226"/>
        <source>Calculating size of root...</source>
        <translation>Beregner størrelsen til root …</translation>
    </message>
</context>
</TS>